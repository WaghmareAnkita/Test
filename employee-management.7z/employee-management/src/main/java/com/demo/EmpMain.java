package com.demo;

import java.util.Arrays;
import java.util.List;

public class EmpMain{

	public static void main(String[] args) {
		EmpDao dao = new EmpDaoJdbcImp();

		
		List<Emp> empList=dao.listAll();
		
		empList.stream().filter(emp->emp.getSalary()>80000).forEach(System.out::println);
		empList.stream().filter(emp->emp.getSalary()<80000).forEach(e->System.out.println(e.getEmpName()));
		
		empList.stream().filter(emp->emp.getSalary()<80000).map(e->e.getEmpName()).forEach(System.out::println);
		
		
		List<String> list=Arrays.asList("Shantanu","John","Peter","Robin","Kirthi","Soham","Jonny","Sheetal","Shankar");
		
		list.stream().filter(name->name.length()>5).forEach(System.out::println);
	}

}
